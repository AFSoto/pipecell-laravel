
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo $__env->yieldContent('title', 'Panel'); ?> — PipeCell</title>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>

    
    <style>
        .sidebar-expanded { width: 16rem; }
        .sidebar-collapsed { width: 5rem; }
        .content-expanded { margin-left: 16rem; }
        .content-collapsed { margin-left: 5rem; }
    </style>
</head>
<body class="min-h-screen bg-gray-50">

    <div class="flex min-h-screen">

        
        
        
        <aside id="sidebar"
               class="fixed inset-y-0 left-0 z-40 bg-[#0f172a] transition-all duration-300 transform -translate-x-full lg:translate-x-0 sidebar-expanded overflow-hidden">

            <div class="flex flex-col h-full">

                
                <div class="px-4 py-5 border-b border-white/10 flex items-center justify-between min-h-[4.5rem]">
                    
                    <div class="sidebar-content flex items-center gap-3 overflow-hidden">
                        <img src="<?php echo e(asset('img/logo.png')); ?>" alt="PipeCell" class="h-10 flex-shrink-0">
                        <div class="sidebar-text whitespace-nowrap">
                            <p class="text-white font-bold text-sm">PipeCell</p>
                            <p class="text-gray-500 text-xs">Panel de control</p>
                        </div>
                    </div>

                    
                    <button onclick="toggleCollapse()"
                            class="hidden lg:flex w-8 h-8 items-center justify-center rounded-lg hover:bg-white/10 transition flex-shrink-0">
                        <svg id="collapse-icon" class="w-4 h-4 text-gray-400 transition-transform duration-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"/>
                        </svg>
                    </button>
                </div>

                
                <nav class="flex-1 px-3 py-6 space-y-1 overflow-y-auto">

                    
                    <a href="<?php echo e(route('admin.dashboard')); ?>"
                       class="sidebar-link flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition
                              <?php echo e(request()->routeIs('admin.dashboard') ? 'bg-blue-600 text-white' : 'text-gray-400 hover:bg-white/5 hover:text-white'); ?>"
                       title="Dashboard">
                        <svg class="w-5 h-5 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"/>
                        </svg>
                        <span class="sidebar-text whitespace-nowrap">Dashboard</span>
                    </a>

                    
                    <a href="<?php echo e(route('admin.reparaciones.index')); ?>"
                       class="sidebar-link flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition
                              <?php echo e(request()->routeIs('admin.reparaciones.*') ? 'bg-blue-600 text-white' : 'text-gray-400 hover:bg-white/5 hover:text-white'); ?>"
                       title="Reparaciones">
                        <svg class="w-5 h-5 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M11.42 15.17l-5.1-5.1a2.5 2.5 0 010-3.54l.71-.7a2.5 2.5 0 013.54 0l5.1 5.1m-4.25 4.24l4.24-4.24m0 0l5.1 5.1a2.5 2.5 0 010 3.54l-.7.7a2.5 2.5 0 01-3.55 0l-5.1-5.1"/>
                        </svg>
                        <span class="sidebar-text whitespace-nowrap">Reparaciones</span>
                    </a>

                    
                    <a href="#"
                       class="sidebar-link flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition text-gray-400 hover:bg-white/5 hover:text-white"
                       title="Cajas">
                        <svg class="w-5 h-5 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4"/>
                        </svg>
                        <span class="sidebar-text whitespace-nowrap">Cajas</span>
                    </a>

                    
                    <a href="#"
                       class="sidebar-link flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition text-gray-400 hover:bg-white/5 hover:text-white"
                       title="Clientes">
                        <svg class="w-5 h-5 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0z"/>
                        </svg>
                        <span class="sidebar-text whitespace-nowrap">Clientes</span>
                    </a>

                    <div class="border-t border-white/10 my-4"></div>

                    
                    <span class="sidebar-link flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium text-gray-600 cursor-not-allowed"
                          title="Inventario (Próximamente)">
                        <svg class="w-5 h-5 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z"/>
                        </svg>
                        <span class="sidebar-text whitespace-nowrap">Inventario</span>
                        <span class="sidebar-text ml-auto text-xs bg-white/5 text-gray-500 px-2 py-0.5 rounded-full whitespace-nowrap">Pronto</span>
                    </span>

                </nav>

                
                <div class="px-3 py-4 border-t border-white/10">

                    <div class="flex items-center gap-3 px-3 py-2 mb-2">
                        <div class="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center text-white text-xs font-bold flex-shrink-0">
                            <?php echo e(strtoupper(substr(auth()->user()->nombre, 0, 2))); ?>

                        </div>
                        <div class="sidebar-text flex-1 min-w-0 whitespace-nowrap">
                            <p class="text-white text-sm font-medium truncate"><?php echo e(auth()->user()->nombre); ?></p>
                            <p class="text-gray-500 text-xs truncate"><?php echo e(auth()->user()->role->label()); ?></p>
                        </div>
                    </div>

                    <form method="POST" action="<?php echo e(route('logout')); ?>">
                        <?php echo csrf_field(); ?>
                        <button type="submit"
                                class="sidebar-link w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium text-gray-400 hover:bg-red-500/10 hover:text-red-400 transition"
                                title="Cerrar sesión">
                            <svg class="w-5 h-5 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"/>
                            </svg>
                            <span class="sidebar-text whitespace-nowrap">Cerrar sesión</span>
                        </button>
                    </form>
                </div>
            </div>
        </aside>

        
        <div id="sidebar-overlay"
             class="fixed inset-0 bg-black/50 z-30 hidden lg:hidden"
             onclick="toggleMobileSidebar()">
        </div>

        
        
        
        <div id="main-content" class="flex-1 transition-all duration-300 lg:content-expanded">

            
            <header class="sticky top-0 z-20 bg-white/80 backdrop-blur-md border-b border-gray-100">
                <div class="flex items-center justify-between px-6 py-4">

                    <button onclick="toggleMobileSidebar()"
                            class="lg:hidden p-2 rounded-xl hover:bg-gray-100 transition">
                        <svg class="w-6 h-6 text-gray-700" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16"/>
                        </svg>
                    </button>

                    <h1 class="text-lg font-semibold text-gray-900">
                        <?php echo $__env->yieldContent('page-title', 'Dashboard'); ?>
                    </h1>

                    <div class="hidden sm:flex items-center gap-2 text-sm text-gray-500">
                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"/>
                        </svg>
                        <?php echo e(now()->translatedFormat('l, d M Y')); ?>

                    </div>
                </div>
            </header>

            <main class="p-6">
                <?php echo $__env->yieldContent('content'); ?>
            </main>

        </div>

    </div>

    
    <script>
        const sidebar = document.getElementById('sidebar');
        const mainContent = document.getElementById('main-content');
        const collapseIcon = document.getElementById('collapse-icon');
        const sidebarTexts = document.querySelectorAll('.sidebar-text');

        // Aplica el estado guardado al cargar
        function applySidebarState() {
            const collapsed = localStorage.getItem('sidebar-collapsed') === 'true';
            if (collapsed) {
                collapseSidebar();
            }
        }

        // Colapsa el sidebar (solo íconos)
        function collapseSidebar() {
            sidebar.classList.remove('sidebar-expanded');
            sidebar.classList.add('sidebar-collapsed');
            mainContent.classList.remove('content-expanded');
            mainContent.classList.add('content-collapsed');
            collapseIcon.style.transform = 'rotate(180deg)';
            sidebarTexts.forEach(el => {
                el.style.opacity = '0';
                el.style.width = '0';
                el.style.overflow = 'hidden';
            });
        }

        // Expande el sidebar (íconos + texto)
        function expandSidebar() {
            sidebar.classList.remove('sidebar-collapsed');
            sidebar.classList.add('sidebar-expanded');
            mainContent.classList.remove('content-collapsed');
            mainContent.classList.add('content-expanded');
            collapseIcon.style.transform = 'rotate(0deg)';
            sidebarTexts.forEach(el => {
                el.style.opacity = '1';
                el.style.width = 'auto';
                el.style.overflow = 'visible';
            });
        }

        // Toggle desktop: colapsar/expandir
        function toggleCollapse() {
            const isCollapsed = sidebar.classList.contains('sidebar-collapsed');
            if (isCollapsed) {
                expandSidebar();
                localStorage.setItem('sidebar-collapsed', 'false');
            } else {
                collapseSidebar();
                localStorage.setItem('sidebar-collapsed', 'true');
            }
        }

        // Toggle móvil: abrir/cerrar como overlay
        function toggleMobileSidebar() {
            sidebar.classList.toggle('-translate-x-full');
            document.getElementById('sidebar-overlay').classList.toggle('hidden');
            // En móvil siempre mostrar expandido
            expandSidebar();
        }

        // Aplicar estado al cargar (solo en desktop)
        if (window.innerWidth >= 1024) {
            applySidebarState();
        }
    </script>

    <?php echo $__env->yieldContent('scripts'); ?>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\pipecell-laravel\resources\views/layouts/admin.blade.php ENDPATH**/ ?>